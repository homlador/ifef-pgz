# Asteroids-Basis
import random
import math

WIDTH = 1280
HEIGHT = 720
TITLE = "Asteroids"

class Player():

    def __init__(self, name):
        self.name = name
        self.lifes = 2
        self.x = 0
        self.y = 20

    def draw(self):
        screen.draw.text(self.name,(self.x,self.y))
        x = self.x
        i = 0
        while i < self.lifes:
            screen.blit("heart",(x,self.y+10))
            x += 50
            i += 1

class Ship(Actor):

    def __init__(self, bild):
        super().__init__(bild)
        print("Neues Raumschiff erzeugt.")
        self.shots = []
        self.normal_speed = 150
        self.speed = self.normal_speed
        self.max_energy = 5
        self.invincible = False # Nachdem ein Asteroid beruehrt wurde ist das Ship fuer einige Sekungen unverwundbar, sonst waere es sofort kaputt
        self.alive = True # Wenn das Schiff explodiert ist, wird dieser Wert auf False gesetzt, und das Ship wird nicht mehr dargestellt

    def get_energy(self):
        return 0 # TODO

    def shoot(self):
        return

    def turbo(self):
        if self.speed is self.normal_speed:
            self.speed = self.speed * 2;
            self.image = self.image + "_turbo"
            self.angle = self.angle # Wenn das Bild neugesetzt wird, muss es auch neu ausgerichtet werden
            clock.schedule_unique(self.reset_turbo, 2.0)

    def reset_turbo(self):
        self.speed = self.normal_speed
        self.image = self.image[0:len(self.image)-6]
        self.angle = self.angle # Wenn das Bild neugesetzt wird, muss es auch neu ausgerichtet werden

    def reset_invincible(self):
        self.invincible = False

    def update(self):
        for shot in self.shots:
            shot.update()

    def update_position(self, dt):
        self.x = self.x + (self.speed*math.cos(math.radians(self.angle))) * dt
        self.y = self.y - (self.speed*math.sin(math.radians(self.angle))) * dt

    def draw(self):
        if self.alive:
            super().draw()
            for shot in self.shots:
                shot.draw()

    def explode(self):
        self.image = "ship_explosion"
        self.angle = self.angle # Wenn das Bild neugesetzt wird, muss es auch neu ausgerichtet werden
        clock.schedule_unique(self.remove_explosion, 2.0)

    def remove_explosion(self):
        self.alive = False


# Spieler 1 wird angelegt
player1 = Player("Alice")
player1.x = 20
ship1 = Ship("playership1_red")
ship1.player = player1 # Damit das Ship auch weiss, zu welchem Player es gehoert
ship1.x = 50
ship1.y = 400
player1.ship = ship1 # Damit der Player auch weiss, welches Schiff zu ihm gehoert

# Asteroiden erzeugen: TODO
asteroids = []

def on_key_down(key):
    if key == keys.SPACE and ship1.alive:
        ship1.shoot()

def update(dt):
    if ship1.alive:
        if keyboard.a:
            ship1.angle += 5
        if keyboard.d:
            ship1.angle -= 5
        if keyboard.w:
            ship1.update_position(dt)
        if keyboard.f:
            ship1.turbo()

    ship1.update()

    for a in asteroids:
        a.update(dt)

def draw():
    screen.fill((0,0,205))
    screen.blit("orion-nebula",(0,0))

    player1.draw()
    ship1.draw()

    for a in asteroids:
        a.draw()
